package com.example.milestone6.access;

import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.IOException;

import com.example.milestone6.contacts.PersonContact;
import com.example.milestone6.supplemental.Location;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * FileAccessService loads and saves contact list from .json files
 * @author Chauncey
 *
 */
public class FileAccessService implements DataAccessService {

    ObjectMapper om = new ObjectMapper();
    Context context;

    public FileAccessService(Context context) {
        this.context = context;
    }

    @Override
    public void saveAllContacts(AddressBook toSave) {

        try {
            File path = context.getExternalFilesDir(null);
            om.writerWithDefaultPrettyPrinter().writeValue(new File(path, "contactList.json"), toSave);
            Log.d("ContactListApplication", "saveAllContacts: Saving Book");
        } catch (JsonGenerationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (JsonMappingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    @Override
    public AddressBook readAllContacts() {
        AddressBook book = new AddressBook();

        try {
            File path = context.getExternalFilesDir(null);
            book = om.readValue(new File(path,"contactList.json"), AddressBook.class);
        } catch (IOException e) {
            book.addContact(new PersonContact("Chance Anderson", "(352)587-3717", new Location(5264,
                    "Abagail Dr", "Spring Hill", "FL", 34608), 7, "11/19/1995",
                    "Reading, Writing, Programming"));
        }

        return book;
    }

}

