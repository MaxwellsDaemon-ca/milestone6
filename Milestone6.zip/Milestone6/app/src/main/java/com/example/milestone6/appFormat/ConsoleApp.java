package com.example.milestone6.appFormat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.milestone6.*;
import com.example.milestone6.access.AddressBook;
import com.example.milestone6.access.FileAccessService;
import com.example.milestone6.contacts.BusinessContact;
import com.example.milestone6.contacts.PersonContact;
import com.example.milestone6.supplemental.Location;


public class ConsoleApp extends AppCompatActivity {

    final String TAG = "ContactListApplication";

    Bundle incoming;

    ListView lv_contacts;
    Button b_search, b_addPersonal, b_addBusiness;
    EditText et_search;

    FileAccessService fas;
    AddressBook book;
    ContactAdapter contactAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "Created");
        findViewsById();

        incoming = getIntent().getExtras();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "Started");

        fas = new FileAccessService(getApplicationContext());
        ((MyApp) this.getApplication()).setBook(fas.readAllContacts());
        book = ((MyApp) this.getApplication()).getBook();
        contactAdapter = new ContactAdapter(this, book);
        lv_contacts.setAdapter(contactAdapter);

        if (incoming != null) {
            Log.d(TAG, "onStart: incoming != null: " + true);
            String name = "", phone = "", street = "", city = "", state = "";
            int iconNum = 1, houseID = 9999, zip = 90009;

            String desc = "", dob = "", hours = "", url = "";

            if (incoming.get("name") != null)
                name = incoming.getString("name");

            if (incoming.get("phone") != null)
                phone = incoming.getString("phone");

            if (incoming.get("street") != null)
                street = incoming.getString("street");

            if (incoming.get("city") != null)
                city = incoming.getString("city");

            if (incoming.get("state") != null)
                state = incoming.getString("state");

            if (incoming.get("iconNum") != null)
                iconNum = incoming.getInt("iconNum");

            if (incoming.get("houseID") != null)
                houseID = incoming.getInt("houseID");

            if (incoming.get("zip") != null)
                zip = incoming.getInt("zip");

            Location l = new Location(houseID, street, city, state, zip);

            if (incoming.get("dob") != null)
                dob = incoming.getString("dob");
            if (incoming.get("desc") != null)
                desc = incoming.getString("desc");

            if (incoming.get("hours") != null)
                hours = incoming.getString("hours");
            if (incoming.get("url") != null)
                url = incoming.getString("url");

            if (!dob.equals("") && !desc.equals("")) {
                PersonContact p = new PersonContact(name, phone, l, iconNum, dob, desc);
                book.addContact(p);
            }

            if (!hours.equals("") && !url.equals("")) {
                BusinessContact b = new BusinessContact(name, phone, l, iconNum, hours, url);
                book.addContact(b);
            }
            incoming = null;
            contactAdapter.notifyDataSetChanged();

        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "Resumed");

        b_addPersonal.setOnClickListener(view -> {
            Intent i = new Intent(view.getContext(), AddPersonalForm.class);
            Log.d(TAG, "Created Intent");
            startActivity(i);
        });

        b_search.setOnClickListener(view -> {
            String searchFor = et_search.getText().toString();
            if (!searchFor.equals("")) {
                AddressBook search = new AddressBook(book.findContacts(searchFor));
                contactAdapter = new ContactAdapter(this, search);
            } else {
                contactAdapter = new ContactAdapter(this, book);
            }
            contactAdapter.notifyDataSetChanged();
        });

    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "Paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "Stopped");
        fas = new FileAccessService(getApplicationContext());
        fas.saveAllContacts(book);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Destroyed");
    }

    private void findViewsById() {
        lv_contacts = (ListView) findViewById(R.id.lv_contacts);
        b_addBusiness = (Button) findViewById(R.id.b_addBusiness);
        b_addPersonal = (Button) findViewById(R.id.b_addPersonal);
        b_search = (Button) findViewById(R.id.b_search);
        et_search = (EditText) findViewById(R.id.et_searchBar);
    }

}