package com.example.milestone6.access;

/**
 * Interface to allow easier access for saving and loading contacts
 * @author Chauncey
 */
public interface DataAccessService {

    public void saveAllContacts(AddressBook toSave);
    public AddressBook readAllContacts();

}

