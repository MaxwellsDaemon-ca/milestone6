package com.example.milestone6.contacts;

import com.example.milestone6.supplemental.Location;
import com.example.milestone6.supplemental.Photo;

import java.io.Serializable;

/**
 * Subclass of BaseContact, specified for personal contacts
 * @author Chauncey
 */
public class PersonContact extends BaseContact implements Serializable {

    private String dob, description;

    /**
     * Default constructor, creates example contact
     */
    public PersonContact() {
        super();
        this.dob = "01/01/1970";
        this.description = "";
    }

    /**
     * Non-default constructor, takes in superclass parameters name and phone
     * @param name the name of the contact
     * @param phone the phone of the contact
     */
    public PersonContact(String name, String phone) {
        super(name, phone);
        this.dob = "";
        this.description = "";
    }

    /**
     * Non-default constructor, takes in superclass parameters name and phone,
     * along with date of birth and description
     * @param name the name of the contact
     * @param phone the phone of the contact
     * @param dob the date of birth of the contact
     * @param desc the description of the contact
     */
    public PersonContact(String name, String phone, String dob, String desc) {
        super(name, phone);
        this.dob = dob;
        this.description = desc;
    }

    /**
     * Non-default constructor, takes in superclass parameters name, phone, and address
     * along with date of birth and description
     * @param name the name of the contact
     * @param phone the phone of the contact
     * @param address the address of the contact
     * @param dob the date of birth of the contact
     * @param desc the description of the contact
     */
    public PersonContact(String name, String phone, Location address, int iconNum, String dob, String desc) {
        super(name, phone, address, iconNum);
        this.dob = dob;
        this.description = desc;
    }

    /**
     * Non-default constructor, takes in all superclass parameters, along with
     * date of birth, and description
     * @param name the name of the contact
     * @param phone the phone of the contact
     * @param address the address of the contact
     * @param photo the photo of the contact
     * @param dob the date of birth of the contact
     * @param desc the description of the contact
     */
    public PersonContact(String name, String phone, Location address, Photo photo,
                         String dob, String desc) {
        super(name, phone, address, photo);
        this.dob = dob;
        this.description = desc;
    }

    /**
     * Getter for date of birth
     * @return the date of birth
     */
    public String getDOB() {
        return dob;
    }

    /**
     * Setter for date of birth
     * @param dob the date of birth to set
     */
    public void setDOB(String dob) {
        this.dob = dob;
    }

    /**
     * Getter for description of contact
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Setter for descriptiong of contact
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Overridden toString() method
     * @return formatted String containing data on the contact
     */
    @Override
    public String toString() {
        return String.format("ID: %d%nName: %s%nPhone: %s%nAddress:%n%s%nDate of Birth: %s%nDescription:%n%s", contactID, name, phone, address.toString(), dob, description);
    }

}
