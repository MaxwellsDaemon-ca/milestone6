package com.example.milestone6.contacts;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;

import com.example.milestone6.supplemental.Photo;
import com.example.milestone6.supplemental.Location;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "type")
@JsonSubTypes({
        @Type(value = BaseContact.class, name = "base"),
        @Type(value = PersonContact.class, name = "person"),
        @Type(value = BusinessContact.class, name = "business")
})
/**
 * Abstract superclass for contacts.
 * @author Chauncey
 */
public abstract class BaseContact implements Comparable<BaseContact>, Serializable {

    protected String name, phone;
    protected int contactID;
    protected ArrayList<Photo> photos;
    protected int iconNum;
    protected Location address;
    @JsonIgnore
    private static final AtomicInteger COUNT = new AtomicInteger(0);

    /**
     * Default constructor, creates fake contact John Doe.
     */
    public BaseContact() {
        this.contactID = COUNT.incrementAndGet();
        this.name = "John Doe";
        this.phone = "(999)867-5309";
        this.photos = createPhotos();
        this.address = new Location();
        this.iconNum = 1;
    }

    /**
     * Non-default constructor that just takes in name and phone number
     * @param name the name of the contact
     * @param phone the phone of the contact
     */
    public BaseContact(String name, String phone) {
        this.contactID = COUNT.incrementAndGet();
        this.name = name;
        this.phone = phone;
        this.address = new Location();
        this.photos = createPhotos();
        this.iconNum = 1;
    }

    /**
     * Non-default constructor, takes in parameters for name, phone number, and address.
     * @param name the name of the contact
     * @param phone the phone of the contact
     * @param address the address of the contact
     * @param iconNum stopGap Measure to hold icon number for picture
     */
    public BaseContact(String name, String phone, Location address, int iconNum) {
        this.contactID = COUNT.incrementAndGet();
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.photos = createPhotos();
        this.iconNum = iconNum;
    }

    /**
     * Non-default constructor, takes in parameters for name, phone, address and photo
     * @param name the name of the contact
     * @param phone the phone of the contact
     * @param address the address of the contact
     * @param photo a photo containing the contact
     */
    public BaseContact(String name, String phone, Location address, Photo photo) {
        this.contactID = COUNT.incrementAndGet();
        this.name = name;
        this.phone = phone;
        this.address = address;
        photos = new ArrayList<>();
        photos.add(photo);
        this.iconNum = 1;
    }

    /**
     * Getter for contact name
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for contact name
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for phone number
     * @return the phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Setter for phone number
     * @param phone the phone to set
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * Getter for photo list
     * @return the photos
     */
    public ArrayList<Photo> getPhotos() {
        return photos;
    }

    /**
     * Setter for Photo list
     * @param photos the photos to set
     */
    public void setPhotos(ArrayList<Photo> photos) {
        this.photos = photos;
    }

    /**
     * Getter for address
     * @return the address
     */
    public Location getAddress() {
        return address;
    }

    /**
     * Setter for address
     * @param address the address to set
     */
    public void setAddress(Location address) {
        this.address = address;
    }

    /**
     * Getter for Contact's ID
     * @return the contactID
     */
    public int getContactID() {
        return contactID;
    }

    /**
     * Getter for Icon number
     * @return the icon number for the picture
     */
    public int getIconNum() {
        return iconNum;
    }

    /**
     * Setter for the icon number
     * @param iconNum the icon number to set
     */
    public void setIconNum(int iconNum) {
        this.iconNum = iconNum;
    }

    /**
     * Method to add a new random photo to the contact
     */
    public void addPhoto() {
        photos.add(new Photo());
    }

    /**
     * Method to add a specific photo to the contact
     * @param p the photo to add
     */
    public void addPhoto(Photo p) {
        photos.add(p);
    }

    /**
     * Method to remove a photo from the contact
     * @param p the photo to remove
     */
    public void removePhoto(Photo p) {
        photos.remove(p);
    }

    /**
     * Override of toString() method
     * @return formatted string of contact information
     */
    @Override
    public String toString() {
        return String.format("ID: %d%nName: %s%nPhone: %s%nAddress:%n%s", contactID, name, phone, address.toString());
    }

    /**
     * Overridden compareTo() method for sorting.
     * @return the comparative sort order, in this case comparing names, and then IDs.
     */
    @Override
    public int compareTo(BaseContact other) {
        int value = this.name.compareToIgnoreCase(other.name);
        if (value == 0) {
            Integer a = this.contactID;
            Integer b = other.contactID;

            return a.compareTo(b);
        }
        return value;
    }

    /**
     * Method to create random photos to attach to contact
     * @return list of random photos
     */
    private ArrayList<Photo> createPhotos() {
        Random r = new Random();
        int toAdd = r.nextInt(5) + 1;
        ArrayList<Photo> add = new ArrayList<>();
        for (int i = 0; i < toAdd; i++) {
            add.add(new Photo());
        }
        return add;
    }

}
