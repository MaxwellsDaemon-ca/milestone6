package com.example.milestone6.access;

import android.util.Log;

import java.util.ArrayList;
import java.util.Collections;

import com.example.milestone6.contacts.*;

/**
 * AddressBook class, designed to process the majority of the methods required to navigate and edit the contact list.
 * @author Chauncey
 */
public class AddressBook {

    private ArrayList<BaseContact> contacts;

    /**
     * Default constructor, creates empty list of contacts
     */
    public AddressBook() {
        this.contacts = new ArrayList<BaseContact>();
    }

    /**
     * Non-default constructor, receives list of contacts
     * @param contacts the contacts to add to the address book
     */
    public AddressBook(ArrayList<BaseContact> contacts) {
        this.contacts = contacts;
    }

    /**
     * Getter Method for getting contacts list
     * @return the list of contacts
     */
    public ArrayList<BaseContact> getContacts() {
        return contacts;
    }

    /**
     * Method to display all of the contacts on the console
     */
    public void displayAll() {
        System.out.println("All Contacts:\n");
        for (BaseContact c : contacts) {
            System.out.printf("Name: %s%nID: %d%nPhone Number: %s%n%n", c.getName(), c.getContactID(), c.getPhone());
        }
        System.out.println("\n*** END OF CONTACTS ***\n");
    }

    /**
     * Method to retrieve a specific BaseContact
     * @param index the index of the contact
     * @return the contact requested for editing
     */
    public BaseContact getContact(int index) {
        return contacts.get(index);
    }

    /**
     * Method to add a new contact
     * @param c the contact to add
     */
    public void addContact(BaseContact c) {
        contacts.add(c);
        sortContacts();
    }

    /**
     * Method to remove a contact from the list
     * @param c the contact to remove
     */
    public void removeContact(BaseContact c) {
        contacts.remove(c);
    }

    /**
     * Method to display a single contact on the console
     * @param c the contact to display
     */
    public void displayContact(BaseContact c) {
        System.out.println(c.toString());
    }

    /**
     * Method to sort the contacts, by name and then ID if identical names.
     */
    public void sortContacts() {
        Collections.sort(contacts);
    }

    /**
     * Method to find specific contacts by using a keyword
     * @param searchFor the thing to search for.
     */
    public ArrayList<BaseContact> findContacts(String searchFor) {
        ArrayList<String> searchList = new ArrayList<>();
        ArrayList<BaseContact> matches = new ArrayList<>();

        for (BaseContact c : contacts)
            searchList.add(c.toString());

        //Searches for instances of keyword in the contacts,
        //then adds the contact to separate list if a match is found
        //using index numbers
        for (String s : searchList)
            if (s.toLowerCase().contains(searchFor.toLowerCase()))
                matches.add(contacts.get(searchList.indexOf(s)));


        return matches;

    }

    /**
     * Searches for a contact by its ID number and prints the match to the console
     * @param id the id to search for
     */
    public BaseContact searchByID(int id) {
        BaseContact returnable = new PersonContact();
        for (BaseContact c : contacts)
            if (id == c.getContactID())
                returnable = c;
        return returnable;
    }

    public boolean checkEmpty() {
        return contacts.isEmpty();
    }
}
