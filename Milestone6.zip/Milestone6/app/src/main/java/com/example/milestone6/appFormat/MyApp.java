package com.example.milestone6.appFormat;

import android.app.Application;
import android.content.Context;

import com.example.milestone6.access.AddressBook;

public class MyApp extends Application {

    private AddressBook book = new AddressBook();

    public AddressBook getBook() {
        return book;
    }

    public void setBook(AddressBook book) {
        this.book = book;
    }
}
