package com.example.milestone6.access;

public class DatabaseAccessService implements DataAccessService{

    @Override
    public void saveAllContacts(AddressBook toSave) {

    }

    @Override
    public AddressBook readAllContacts() {
        return null;
    }
}
