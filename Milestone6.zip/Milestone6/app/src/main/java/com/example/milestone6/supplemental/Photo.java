package com.example.milestone6.supplemental;

import java.io.Serializable;
import java.util.concurrent.atomic.AtomicInteger;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * Supplemental class for Photo object.
 * @author Chauncey
 */
public class Photo implements Serializable {

    private String fileName, description;
    @JsonIgnore
    private static final AtomicInteger COUNT = new AtomicInteger(0);

    /**
     * Default Constructor for photo class. Creates incremented ID number,
     * date of photo, blank description, and formatted filename of ID and date.
     */
    public Photo() {
        this.description = "";
        this.fileName = String.format("Photo:%04d", COUNT.incrementAndGet());
    }

    /**
     * Non-Default constructor, functionally the same as default,
     * but allows for description.
     * @param description description of the photo
     */
    public Photo(String description) {
        this.description = description;
        this.fileName = String.format("Photo:%04d", COUNT.incrementAndGet());
    }

    /**
     * Getter for the file name of the photo
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Setter for the file name of the photo
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Getter for the description of the photo
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Setter for the description of the photo
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Overridden toString method
     * @return the filename and the description
     */
    @Override
    public String toString() {
        return String.format("Photo file name: %s - Description: %s", this.fileName, this.description);
    }



}
